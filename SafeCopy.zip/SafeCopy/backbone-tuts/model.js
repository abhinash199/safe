var Tutorial = Backbone.Model.extend({
    initialize:function(){
        console.log("Welcome")
    }
})

var backbone = new Tutorial();