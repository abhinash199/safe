var Tutorial = Backbone.Model.extend({
    // initialize:function(){
    //     console.log("Welcome")
    // }
    defaults:{
        platform:"Youtube"
    }
})

var backbone = new Tutorial({
    // name:"Abhinash",
    // Tech: "React Developer"
});

backbone.set({
    name:"Abhinash",
    Tech: "React Developer"
})