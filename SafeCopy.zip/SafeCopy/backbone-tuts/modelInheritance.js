var demo=Backbone.Model.extend({
    show:function(){
        console.log("Parent function");
    }
});




var demoShow=demo.extend({
    show:function(){
        demo.prototype.show.apply();
        console.log('child function');
    }
});

var k=new demoShow();